# RTX 4090 typical-scene archive

This example accompanies FBME-SBL's original matched-device SMV comparison
(Table 2 GPU rows and Figure 3). It contains **actual archived RTX 4090
measurements**, their protocol, and a static SVG redraw entry point. It is
separate from the later RTX 3080 generalization study.

**Reproduction scope:** the supplied files reproduce the reported table/plot
from frozen measurements. They are not a complete rerunnable experiment: the
original RTX 4090 runner and the exact seed-200 input-generation implementation
are missing from the available release materials. No solver was rerun and no
new measurements were generated for this package.

## Recorded setting

- NVIDIA GeForce RTX 4090; PyTorch 2.6.0+cu124; CUDA 12.4; complex64.
- A 40 by 32 reflectivity grid and 20 by 16 Fourier observations:
  N = 1280, M = 320, M/N = 1/4.
- Seed 200, 21 random-phase targets, 10-dB SNR, complex noise.
- Eight methods, each with 20 CUDA-event and 20 host timing samples.
- Quality refers to **one shared scene per method**. The 20 repeats are timing
  repetitions, not 20 independent recovery trials.
- P50 is the mean of sorted positions 10 and 11; the archived upward-interpolated
  P95 is the observed maximum of the 20 timings.

See [PROTOCOL.md](PROTOCOL.md) and [protocol.json](protocol.json) for method
settings, units, timing boundaries and known missing information.

## Files

- `archive/paper_smv_matched_v9.json`: original frozen result, unchanged bytes;
  all 160 device timings, 160 host timings, quality counts and configurations.
- `archive/summary.csv`: device P50/P95 in milliseconds, host P50 in milliseconds,
  raw complex NMSE, support F1, sample counts and archived warmup counts.
- `archive/timing_samples.csv`: individual timings; `sample_index` is one-based.
- `archive/quality.csv`: archived reconstruction-quality summaries and counts.
- `figures/latency_nmse_tradeoff.svg`: editable vector figure with 9-point labels.
- `figures/latency_nmse_tradeoff.pdf` and `.png`: existing Inkscape exports.
- `tools/rebuild_archived_outputs.py`: static results/figure adapter using only
  Python's standard library. It does not import or run any solver.
- `PROVENANCE.md`, `source_manifest.json`, `manifest.json`, `SHA256SUMS.txt`:
  source identities, hashes, and package inventory.

## Rebuild the plot and summary from the archived results

Run from the repository root with Python 3.10 or newer:

```bash
python examples/rtx4090_typical/tools/rebuild_archived_outputs.py
```

This creates a new `generated/summary.csv` and editable
`generated/latency_nmse_tradeoff.svg`, leaving the archive unchanged. The adapter
was checked by static AST parsing only during packaging; it was not executed.
No CUDA/PyTorch installation is needed for this static redraw. For vector PDF
and PNG exports, install Inkscape and a Times-compatible font, then run:

```bash
inkscape examples/rtx4090_typical/generated/latency_nmse_tradeoff.svg --export-type=pdf --export-filename=examples/rtx4090_typical/generated/latency_nmse_tradeoff.pdf
inkscape examples/rtx4090_typical/generated/latency_nmse_tradeoff.svg --export-width=2400 --export-filename=examples/rtx4090_typical/generated/latency_nmse_tradeoff.png
```

The supplied figure uses SVG plus Inkscape, not a raster image disguised as a
vector graphic. Its axes and point values are unchanged from the frozen archive.

## Running the numerical solvers

The sibling `torch_sbl`, `torch_sbl_fastest_stable`, and
`literature_reproduction` packages provide numerical interfaces. This archive
records the 4090 settings but **does not provide a historical end-to-end runner
or an exact replacement data generator**. A seed alone does not specify the
RNG backend, draw order, scatterer distribution and noise normalization. Do not
substitute the 3080 generator and label the result a reproduction of this run.

The recorded `literature_reproduction/baselines.py` hash matches the released
file. The archived GGAMP/AFCIFSBL file hashes do not match their renamed release
counterparts, and FBME core hashes are not recorded in this JSON. See
[PROVENANCE.md](PROVENANCE.md). Fresh experiments must be identified separately,
with their complete environment, input hashes, source commit and settings.

The two historical CPU rows of Table 2 are outside this eight-GPU-method archive;
they are intentionally not repackaged as matched-device measurements. No raw
radar echo, manuscript, private data or internal project records are included.

Licensing follows the repository's root `NOTICE.md`; no additional open-source
license is assigned by this example.
