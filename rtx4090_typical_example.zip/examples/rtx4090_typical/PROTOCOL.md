# Recorded RTX 4090 protocol

This document transcribes the frozen archive and the original comparison
protocol. It is not evidence that a new benchmark was run.

## Scene and measurement model

The recorded single-measurement-vector partial-Fourier scene has a 40 by 32
reconstruction grid (N = 1280), 20 by 16 observations (M = 320), 21 random-phase
targets, seed 200 and 10-dB signal-to-noise ratio. The reconstruction uses raw
complex values. The exact generator, RNG backend/draw order, target-amplitude
law, observation array and ground-truth coefficients are not supplied here.
The Fourier sampling/normalization details cannot be reconstructed from the
seed alone. The current numerical operator API does not fill this archival gap.

## Environment and time accounting

The archive identifies NVIDIA GeForce RTX 4090, complex64, and PyTorch
2.6.0+cu124. CUDA 12.4 is the recorded comparison environment; no exact Triton,
Python or driver version is available in the frozen JSON.

Each method has 20 `device_ms` samples measured with CUDA events and 20
`host_ms` samples. The recorded timed boundary is resident-input copy plus the
full warmed solver. Setup/JIT compilation is excluded. Warmup counts differ by
method and are retained exactly in `protocol.json`; they should not be replaced
by one arbitrary common number. The JSON does not preserve a complete original
host-timing harness or all CUDA synchronization instructions.

Device P50 uses (t_(10) + t_(11))/2 after sorting 20 samples. The archived P95 uses
upward interpolation and is t_(20), the observed maximum. This is not the linear
P95 estimator of the later RTX 3080 study. Timings have units of milliseconds.
Figure 3 and the main timing columns use device measurements, not host P50.

## Quality

Raw complex NMSE is sum(abs(x_hat - x)^2) / sum(abs(x)^2), with no fitted gain
alignment. It is dimensionless and is reported in linear scale, not dB.
Autonomous support uses abs(mu_j)^2 / Sigma_jj > log(N/nu), with nu = 0.5.
F1 = 2 TP / (2 TP + FP + FN). The archived threshold is
7.847762537473608 = log(1280/0.5). The `oracle_k_hits` field is an archived
secondary diagnostic, not the reported autonomous support F1.

Each method has one quality summary for the common seed-200 scene. No confidence
interval or multi-seed generalization claim is inferred from these eight rows.

## Method settings

| Method | Recorded setting | Noise handling / qualifications |
|---|---|---|
| Dense EM-SBL | 30 EM iterations; exact observation-domain posterior | Evidence noise update |
| CoFEM | 30 outer iterations; 31 E-steps; 20 probes; at most 400 CG steps; squared relative CG tolerance 1e-5 | Oracle-fixed noise |
| UAMP-SBL | 30 message iterations; adaptive epsilon; no online SVD | Algorithm-2 noise update; partial unnormalized DFT row orthogonality |
| Triton UAMP | 30 message iterations; no adaptive epsilon; no active-set polish | Engineering variant; learned noise |
| GGAMP-SBL | 15 EM iterations; at most 15 messages per EM; 201 total realized message updates; theta_s = theta_x = 0.35; tolerance 1e-5 | Realized oracle-fixed noise in this old run; do not replace it with current wrapper defaults |
| 2D-AFCIFSBL | At most 30 updates; tolerance 1e-4; Lipschitz value 2560; phase updates retained; weak Gamma defaults 1e-6 | Realized iteration count is preserved in the JSON |
| FBME-Fast | K = 32; T_u = 4; T_e = 2; L = 0; locked CUDA Graph | Foreground diagnostics disabled |
| FBME-Stable | K = 32; T_u = 4; T_e = 3; L = 12; locked CUDA Graph | Foreground diagnostics enabled |

The compared settings use different update budgets and noise information. These
are matched-scene measured configurations, not equal-accuracy or equal-budget
speedups. The JSON's historical implementation descriptions are retained
verbatim; repository `SOURCES.md` provides the release's independent-
implementation attribution and licensing context.

## Missing materials for an exact numerical rerun

1. Original RTX 4090 matched-comparison runner and its full invocation.
2. Exact seed-200 scene-generation function, RNG state/backend/draw order,
   ground-truth coefficients and complex observation array.
3. The exact old GGAMP and AFCIFSBL source files or a documented diff to their
   current renamed counterparts; FBME core source hashes for the archived run.
4. Full driver/Python/Triton environment and original warmup/timing harness.
5. Per-method recovered complex arrays for independently recomputing NMSE.

The available archive does support independent recomputation of its P50/P95,
F1 from TP/FP/FN and table/plot values. The listed gaps are not filled with newly
invented settings or later RTX 3080 data.
