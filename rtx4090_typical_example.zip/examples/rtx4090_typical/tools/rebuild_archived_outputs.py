"""Rebuild summaries and an SVG from frozen RTX 4090 measurements.

This is a static results/figure adapter, not an experiment runner. It does not
import the numerical solvers, generate a scene, benchmark a GPU, or fit a model.
The SVG functions are extracted from the existing publication redraw script;
identifiers/comments and filesystem interfaces are adapted for this release.
This adapted entry point was syntax-checked only, not executed for this release.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from html import escape
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_PATH = PACKAGE_ROOT / "archive" / "paper_smv_matched_v9.json"
FIGURE_WIDTH = 243.78
FIGURE_HEIGHT = 111.30
OUTPUT_SVG = PACKAGE_ROOT / "generated" / "latency_nmse_tradeoff.svg"
EXPECTED_SHA256 = "0f9e79fdc4a9597b386dbd3f3088b957caf56d30478d9ecf0262151eeb559e4a"

def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def svg_header(width: float, height: float, description: str, source_hash: str) -> list[str]:
    return [
        '<?xml version="1.0" encoding="UTF-8"?>',
        (
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'width="{width:.2f}pt" height="{height:.2f}pt" '
            f'viewBox="0 0 {width:.2f} {height:.2f}" version="1.1">'
        ),
        f"<title>{escape(description)}</title>",
        f"<desc>{escape(description)} Source SHA-256: {source_hash}.</desc>",
        (
            '<style>'
            'text{font-family:"Times New Roman","Nimbus Roman","Liberation Serif",serif;fill:#111}'
            '.label{font-size:9.2px}'
            '.plottext{font-size:9px}'
            '.halo{paint-order:stroke fill;stroke:#fff;stroke-width:1.45px;stroke-linejoin:round}'
            '</style>'
        ),
        '<rect x="0" y="0" width="100%" height="100%" fill="#fff"/>',
    ]


def plot_coordinates(x: float, y: float) -> tuple[float, float]:
    left, right, top, bottom = 35.0, 239.0, 7.0, 84.0
    xmin, xmax = math.log10(0.45), math.log10(500.0)
    px = left + (math.log10(x) - xmin) / (xmax - xmin) * (right - left)
    py = top + (0.20 - y) / 0.20 * (bottom - top)
    return px, py


def marker_svg(kind: str, x: float, y: float, color: str) -> str:
    edge = "#ffffff"
    if kind == "circle":
        return f'<circle cx="{x:.2f}" cy="{y:.2f}" r="2.95" fill="{color}" stroke="{edge}" stroke-width="0.45"/>'
    if kind == "square":
        return f'<rect x="{x-2.95:.2f}" y="{y-2.95:.2f}" width="5.90" height="5.90" fill="{color}" stroke="{edge}" stroke-width="0.45"/>'
    if kind == "diamond":
        return f'<path d="M{x:.2f},{y-3.7:.2f} L{x+3.7:.2f},{y:.2f} L{x:.2f},{y+3.7:.2f} L{x-3.7:.2f},{y:.2f} Z" fill="{color}" stroke="{edge}" stroke-width="0.45"/>'
    if kind == "triangle-up":
        return f'<path d="M{x:.2f},{y-3.8:.2f} L{x+3.6:.2f},{y+3.1:.2f} L{x-3.6:.2f},{y+3.1:.2f} Z" fill="{color}" stroke="{edge}" stroke-width="0.45"/>'
    if kind == "triangle-down":
        return f'<path d="M{x-3.6:.2f},{y-3.1:.2f} L{x+3.6:.2f},{y-3.1:.2f} L{x:.2f},{y+3.8:.2f} Z" fill="{color}" stroke="{edge}" stroke-width="0.45"/>'
    if kind == "plus":
        return f'<path d="M{x-1.2:.2f},{y-3.8:.2f} H{x+1.2:.2f} V{y-1.2:.2f} H{x+3.8:.2f} V{y+1.2:.2f} H{x+1.2:.2f} V{y+3.8:.2f} H{x-1.2:.2f} V{y+1.2:.2f} H{x-3.8:.2f} V{y-1.2:.2f} H{x-1.2:.2f} Z" fill="{color}" stroke="{edge}" stroke-width="0.40"/>'
    if kind == "x":
        return f'<g stroke="{color}" stroke-width="2.15" stroke-linecap="round"><line x1="{x-2.8:.2f}" y1="{y-2.8:.2f}" x2="{x+2.8:.2f}" y2="{y+2.8:.2f}"/><line x1="{x+2.8:.2f}" y1="{y-2.8:.2f}" x2="{x-2.8:.2f}" y2="{y+2.8:.2f}"/></g>'
    if kind == "star":
        pts = []
        for i in range(10):
            radius = 4.25 if i % 2 == 0 else 1.8
            angle = -math.pi / 2 + i * math.pi / 5
            pts.append(f"{x + radius * math.cos(angle):.2f},{y + radius * math.sin(angle):.2f}")
        return f'<polygon points="{" ".join(pts)}" fill="{color}" stroke="{edge}" stroke-width="0.45"/>'
    raise ValueError(kind)


def write_latency_svg() -> None:
    payload = json.loads(ARCHIVE_PATH.read_text(encoding="utf-8"))
    rows = {row["id"]: row for row in payload["rows"]}
    order = [
        "dense_em_sbl",
        "cofem_2022",
        "uamp_sbl_2021",
        "uamp_core_triton",
        "ggamp_sbl_2018",
        "afcifsbl_2d_2024",
        "fbme_fastest",
        "fbme_stable",
    ]
    if set(order) - rows.keys():
        raise KeyError("The frozen archive is missing a required method.")

    labels = {
        "dense_em_sbl": "Dense EM",
        "cofem_2022": "CoFEM",
        "uamp_sbl_2021": "UAMP",
        "uamp_core_triton": "Triton UAMP",
        "ggamp_sbl_2018": "GGAMP",
        "afcifsbl_2d_2024": "2D-AFCIFSBL",
        "fbme_fastest": "FBME-Fast",
        "fbme_stable": "FBME-Stable",
    }
    colors = {
        "dense_em_sbl": "#777777",
        "cofem_2022": "#8055a6",
        "uamp_sbl_2021": "#2f6f9f",
        "uamp_core_triton": "#4d94cc",
        "ggamp_sbl_2018": "#518444",
        "afcifsbl_2d_2024": "#9c663e",
        "fbme_fastest": "#d98324",
        "fbme_stable": "#b3282d",
    }
    markers = {
        "dense_em_sbl": "square",
        "cofem_2022": "diamond",
        "uamp_sbl_2021": "triangle-up",
        "uamp_core_triton": "triangle-down",
        "ggamp_sbl_2018": "plus",
        "afcifsbl_2d_2024": "x",
        "fbme_fastest": "circle",
        "fbme_stable": "star",
    }

    label_pos = {
        "dense_em_sbl": (177.5, 42.0, "start"),
        "cofem_2022": (205.0, 80.0, "end"),
        "uamp_sbl_2021": (157.5, 62.5, "start"),
        "uamp_core_triton": (139.5, 61.0, "end"),
        "ggamp_sbl_2018": (235.0, 52.5, "end"),
        "afcifsbl_2d_2024": (168.0, 27.5, "middle"),
        "fbme_fastest": (39.0, 60.0, "start"),
        "fbme_stable": (67.0, 73.0, "start"),
    }

    svg = svg_header(
        FIGURE_WIDTH,
        FIGURE_HEIGHT,
        "RTX 4090 latency-accuracy comparison with 9-point vector labels",
        file_sha256(ARCHIVE_PATH),
    )
    left, right, top, bottom = 35.0, 239.0, 7.0, 84.0

    for decade in (-1, 0, 1, 2):
        for mul in range(2, 10):
            value = mul * (10.0 ** decade)
            if 0.45 < value < 500.0:
                x, _ = plot_coordinates(value, 0.0)
                svg.append(f'<line x1="{x:.2f}" y1="{top:.2f}" x2="{x:.2f}" y2="{bottom:.2f}" stroke="#eeeeee" stroke-width="0.35"/>')
    for value in (1.0, 10.0, 100.0):
        x, _ = plot_coordinates(value, 0.0)
        svg.append(f'<line x1="{x:.2f}" y1="{top:.2f}" x2="{x:.2f}" y2="{bottom:.2f}" stroke="#d8d8d8" stroke-width="0.45"/>')
    for value in (0.0, 0.05, 0.10, 0.15, 0.20):
        _, y = plot_coordinates(1.0, value)
        svg.append(f'<line x1="{left:.2f}" y1="{y:.2f}" x2="{right:.2f}" y2="{y:.2f}" stroke="#d8d8d8" stroke-width="0.45"/>')

    svg.append(f'<rect x="{left:.2f}" y="{top:.2f}" width="{right-left:.2f}" height="{bottom-top:.2f}" fill="none" stroke="#111" stroke-width="0.65"/>')

    for value in (0.0, 0.05, 0.10, 0.15, 0.20):
        _, y = plot_coordinates(1.0, value)
        svg.append(f'<line x1="{left-2.5:.2f}" y1="{y:.2f}" x2="{left:.2f}" y2="{y:.2f}" stroke="#111" stroke-width="0.55"/>')
        svg.append(f'<text class="plottext" x="{left-4.0:.2f}" y="{y+3.0:.2f}" text-anchor="end">{value:.2f}</text>')

    for value, exponent in ((1.0, "0"), (10.0, "1"), (100.0, "2")):
        x, _ = plot_coordinates(value, 0.0)
        svg.append(f'<line x1="{x:.2f}" y1="{bottom:.2f}" x2="{x:.2f}" y2="{bottom+2.5:.2f}" stroke="#111" stroke-width="0.55"/>')
        svg.append(
            f'<text class="plottext" x="{x:.2f}" y="{bottom+11.0:.2f}" text-anchor="middle">'
            f'10<tspan font-size="6.8px" baseline-shift="super">{exponent}</tspan></text>'
        )

    svg.append(f'<text class="plottext" x="{(left+right)/2:.2f}" y="108.0" text-anchor="middle">Median device latency (ms, log scale)</text>')
    svg.append(f'<text class="plottext" x="9.5" y="{(top+bottom)/2:.2f}" text-anchor="middle" transform="rotate(-90 9.5 {(top+bottom)/2:.2f})">Raw complex NMSE</text>')
    svg.append('<text class="plottext" x="38.0" y="16.0" fill="#555">lower left is better</text>')

    points: dict[str, tuple[float, float]] = {}
    for method in order:
        row = rows[method]
        points[method] = plot_coordinates(float(row["p50_ms"]), float(row["quality"]["nmse"]))
        x, y = points[method]
        tx, ty, anchor = label_pos[method]
        target_x = tx - 2.0 if anchor == "start" else tx + 2.0 if anchor == "end" else tx
        target_y = ty - 3.0
        svg.append(f'<line x1="{x:.2f}" y1="{y:.2f}" x2="{target_x:.2f}" y2="{target_y:.2f}" stroke="#7c858c" stroke-width="0.45"/>')

    for method in order:
        x, y = points[method]
        svg.append(marker_svg(markers[method], x, y, colors[method]))
    for method in order:
        tx, ty, anchor = label_pos[method]
        svg.append(
            f'<text class="plottext halo" x="{tx:.2f}" y="{ty:.2f}" text-anchor="{anchor}" '
            f'fill="#222">{escape(labels[method])}</text>'
        )
    svg.append("</svg>")
    OUTPUT_SVG.write_text("\n".join(svg), encoding="utf-8")


def main() -> None:
    global OUTPUT_SVG
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=PACKAGE_ROOT / "generated")
    args = parser.parse_args()
    if file_sha256(ARCHIVE_PATH) != EXPECTED_SHA256:
        raise ValueError("The frozen result archive differs from the published SHA-256.")
    data = json.loads(ARCHIVE_PATH.read_text(encoding="utf-8"))
    summaries = []
    for row in data["rows"]:
        samples = sorted(row["device_ms"])
        if len(samples) != 20 or len(row["host_ms"]) != 20:
            raise ValueError(f"Unexpected timing sample count: {row['id']}")
        p50 = (samples[9] + samples[10]) / 2.0
        p95 = samples[-1]
        if not math.isclose(p50, row["p50_ms"], rel_tol=1e-12):
            raise ValueError(f"Archived P50 mismatch: {row['id']}")
        if not math.isclose(p95, row["p95_ms"], rel_tol=1e-12):
            raise ValueError(f"Archived P95 mismatch: {row['id']}")
        summaries.append({"method_id": row["id"], "device_p50_ms": p50,
                          "device_p95_ms": p95, "raw_complex_nmse": row["quality"]["nmse"],
                          "support_f1": row["quality"]["f1"]})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / "summary.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    OUTPUT_SVG = args.output_dir / "latency_nmse_tradeoff.svg"
    write_latency_svg()
    print(f"Rebuilt archived summaries and SVG in {args.output_dir}")

if __name__ == "__main__":
    main()
