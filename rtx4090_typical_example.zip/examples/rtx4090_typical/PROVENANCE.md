# Sources, compatibility and limitations

The frozen JSON is copied byte-for-byte from the existing v13 LaTeX source
bundle, member `figures/paper_smv_matched_v9.json`. Its SHA-256 is
`0f9e79fdc4a9597b386dbd3f3088b957caf56d30478d9ecf0262151eeb559e4a`.
The release does not contain the manuscript itself. All source and artifact
hashes are listed in `source_manifest.json`.

The old `make_figures.py` contains `make_latency_quality_tradeoff` and
`make_latency_table`, both reading this JSON without running a solver. The whole
script is not bundled because it also handles unrelated manuscript/ISAR assets.
The included redraw adapter extracts only the existing SVG plot functions from
the later 9-point label repair, translates identifiers/comments to English and
uses relative paths. Plot data, transforms, colors, markers and label positions
are preserved. The supplied SVG/PDF/PNG are unchanged existing outputs of that
SVG/Inkscape workflow. The adapter is syntax-checked, not runtime-validated.

## Recorded source hashes versus released code

| Archived module | Release counterpart | Byte-identical? |
|---|---|---|
| `literature_reproduction/baselines.py` | Same path | Yes |
| `literature_reproduction/new_comparison_papers/ggamp_sbl_2018.py` | `literature_reproduction/ggamp_reimplementation.py` | No |
| `literature_reproduction/new_comparison_papers/afcifsbl_2024.py` | `literature_reproduction/afcifsbl_reimplementation.py` | No |

A different file hash does not by itself prove a numerical change, but equality
has not been established. The complete original runner and old corresponding
modules are not in the available experiment materials. Do not claim bitwise
reproduction from the current code. FBME core hashes are not recorded in this
archive, so their exact historical identity cannot be certified either.

The original JSON uses the historical wording "independent complex-Fourier
adaptation of author code" for CoFEM. This is preserved as archival metadata,
not a new claim that third-party source code is bundled. The current release's
independent implementation and citation statements remain in root `SOURCES.md`.

`summary.csv`, `timing_samples.csv` and `quality.csv` are direct static
transformations of the archived numbers. All eight P50 values, upward P95 values,
host P50 values and F1 counts were independently checked during packaging.
No new input, reconstruction or performance number was produced.

The fixed seed and target count are insufficient to recreate the exact scene.
The missing runner, input arrays and generation details are listed in
`PROTOCOL.md`. Later RTX 3080 results and their generator are not included.

The package's `manifest.json` and `SHA256SUMS.txt` list every payload file except
themselves to avoid a recursive checksum definition. Licensing follows the root
repository notice; no rights or third-party licenses are inferred by this archive.
